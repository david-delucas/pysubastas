"""Let's find some subastas!"""

__version__ = "0.1.0"


def search(name, count=5):
    """Search subastas by name."""
    raise NotImplementedError()